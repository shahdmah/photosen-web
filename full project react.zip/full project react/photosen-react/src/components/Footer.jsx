export default function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        © {new Date().getFullYear()} Shahd Salama. All Rights Reserved.
      </div>
    </footer>
  );
}
